# Halls’n’All (Unified Next.js Project)

## Local run
1) Install Node.js 18+
2) In this folder:
   - `npm install`
   - `npm run dev`
3) Open http://localhost:3000

## Deploy (Vercel)
1) Upload this folder to a GitHub repository
2) In Vercel: New Project → Import GitHub repo → Deploy
3) Add your domain `hallsnall.com`

## Forms
Early access and vendor apply are wired to Formspree:
- https://formspree.io/f/maqdwnbo

Redirect after submit:
- https://hallsnall.com/thanks
